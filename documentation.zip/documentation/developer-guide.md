# Developer Guide

## Project Structure

```
contact-center-agents/
├── shared/                    # Shared utilities and base classes
│   ├── models.py             # Pydantic data models
│   ├── base_agent.py         # Base class for utility agents
│   ├── claude_client.py      # Claude/Bedrock client
│   └── gateway_client.py     # AgentCore Gateway client
├── orchestrator/             # Multi-Agent Orchestrator
│   ├── agent.py              # Orchestrator implementation
│   └── main.py               # FastAPI server
├── agents/                   # Utility agents
│   ├── billing/
│   ├── faq/
│   ├── product_info/
│   └── ...
├── infrastructure/           # Terraform IaC for AgentCore
├── tests/                    # Unit tests
└── documentation/            # This folder
```

## Development Workflow

### Setting Up Development Environment

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install with dev dependencies
pip install -e ".[dev]"

# Install pre-commit hooks (optional)
pre-commit install
```

### Code Style

We use the following tools:
- Black for code formatting (line length: 100)
- Ruff for linting
- MyPy for type checking

```bash
black .
ruff check .
mypy shared/ orchestrator/ agents/
```

### Running Tests

```bash
pytest tests/ -v
pytest --cov=shared --cov-report=html
pytest tests/test_billing.py::TestBillingAgent -v
```

## Adding a New Utility Agent

### Step 1: Create Agent Directory

```bash
mkdir -p agents/new_agent
touch agents/new_agent/__init__.py
touch agents/new_agent/agent.py
touch agents/new_agent/main.py
touch agents/new_agent/Dockerfile
```

### Step 2: Implement the Agent

```python
# agents/new_agent/agent.py
from typing import Any
from shared.base_agent import BaseUtilityAgent
from shared.claude_client import ClaudeClient
from shared.gateway_client import AgentCoreGatewayClient
from shared.models import AgentType, ToolCall, ToolResult


class NewAgent(BaseUtilityAgent):
    """Agent for handling new domain queries."""

    def __init__(
        self,
        gateway_client: AgentCoreGatewayClient | None = None,
        claude_client: ClaudeClient | None = None,
    ):
        super().__init__(AgentType.NEW_AGENT, gateway_client, claude_client)

    @property
    def system_prompt(self) -> str:
        return """You are a New Agent specializing in..."""

    @property
    def available_tools(self) -> list[dict[str, Any]]:
        return [
            {
                "name": "tool_name",
                "description": "What this tool does",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "param1": {"type": "string", "description": "Parameter"}
                    },
                    "required": ["param1"]
                }
            }
        ]

    def execute_tool(self, tool_name: str, tool_input: dict[str, Any]) -> ToolResult:
        if tool_name == "tool_name":
            return self.gateway.invoke_tool(
                ToolCall(tool_name="gateway_tool_name", parameters=tool_input)
            )
        return ToolResult(tool_name=tool_name, success=False, error="Unknown tool")
```

### Step 3: Create FastAPI Server

```python
# agents/new_agent/main.py
import logging
import os
import uuid
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from shared.models import AgentRequest, AgentResponse, Priority
from .agent import NewAgent

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"))
agent: NewAgent | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global agent
    agent = NewAgent()
    yield
    if agent:
        agent.gateway.close()


app = FastAPI(title="New Agent", version="1.0.0", lifespan=lifespan)


@app.get("/health")
async def health_check():
    if agent is None:
        raise HTTPException(status_code=503, detail="Agent not initialized")
    return await agent.health_check()


@app.post("/process", response_model=AgentResponse)
async def process_query(request: ProcessRequest):
    if agent is None:
        raise HTTPException(status_code=503, detail="Agent not initialized")
    agent_request = AgentRequest(
        request_id=str(uuid.uuid4()),
        query=request.query,
        customer_id=request.customer_id,
        priority=Priority(request.priority),
        context=request.context,
    )
    return await agent.process_request(agent_request)
```

### Step 4: Add Dockerfile

```dockerfile
FROM python:3.11-slim
WORKDIR /app
RUN apt-get update && apt-get install -y --no-install-recommends curl \
    && rm -rf /var/lib/apt/lists/*
COPY shared/requirements.txt /app/requirements.txt
RUN pip install --no-cache-dir -r requirements.txt
COPY shared /app/shared
COPY agents/new_agent /app/agents/new_agent
ENV PYTHONPATH=/app
EXPOSE 8080
HEALTHCHECK --interval=30s --timeout=5s --start-period=60s --retries=3 \
    CMD curl -f http://localhost:8080/health || exit 1
CMD ["python", "-m", "agents.new_agent.main"]
```

### Step 5: Register in Infrastructure

Update `infrastructure/main.tf`:

```hcl
locals {
  utility_agents = [
    # ... existing agents
    "new-agent"
  ]
}
```

### Step 6: Write Tests

```python
# tests/test_new_agent.py
import pytest
from unittest.mock import patch
from shared.models import AgentType


class TestNewAgent:
    @pytest.fixture
    def agent(self, mock_gateway, mock_claude):
        with patch.dict("os.environ", {"AWS_REGION": "us-east-1"}):
            from agents.new_agent.agent import NewAgent
            return NewAgent(gateway_client=mock_gateway, claude_client=mock_claude)

    def test_init(self, agent):
        assert agent.agent_type == AgentType.NEW_AGENT
```

## Working with Claude

### Tool Definitions

```python
{
    "name": "tool_name",
    "description": "...",
    "input_schema": {
        "type": "object",
        "properties": {
            "param": {"type": "string", "description": "..."}
        },
        "required": ["param"]
    }
}
```

### Best Practices

1. Clear descriptions - Claude uses descriptions to decide when to use tools
2. Specific parameters - Use enums where possible
3. Required vs optional - Only mark truly required params as required
4. Error handling - Always return ToolResult with success=False on errors

## Gateway Integration

```python
# Using convenience methods
result = self.gateway.query_salesforce(query, object_type)
result = self.gateway.search_confluence(query, space_key)
result = self.gateway.query_servicenow(table, query, limit)

# Using generic invoke_tool
result = self.gateway.invoke_tool(
    ToolCall(tool_name="custom_tool", parameters={"key": "value"}, timeout_seconds=30)
)
```

## AgentCore Deployment

### Building for AgentCore

```bash
# Build and push to ECR
./scripts/build_and_push.sh

# Deploy to AgentCore
DEPLOY=true ./scripts/build_and_push.sh
```

### Environment Variables in AgentCore

Environment variables are configured in `infrastructure/agentcore.tf`:

```hcl
environment_variables = {
  AWS_REGION       = var.aws_region
  BEDROCK_MODEL_ID = var.bedrock_model_id
  LOG_LEVEL        = var.environment == "prod" ? "INFO" : "DEBUG"
}
```

## Debugging

### Local Debugging

```python
import logging
logging.basicConfig(level=logging.DEBUG)
logger.debug(f"Tool input: {tool_input}")
```

### CloudWatch Logs

```bash
aws logs tail /aws/bedrock/agentcore/contact-center-dev --follow
```

## Contributing

1. Create feature branch from `main`
2. Write tests for new functionality
3. Ensure all tests pass
4. Update documentation
5. Submit pull request

### Commit Message Format

```
type(scope): description

- feat: New feature
- fix: Bug fix
- docs: Documentation
- test: Tests
- refactor: Code refactoring
```


---

## Lambda Integration

This section provides sample code for invoking the orchestrator from an AWS Lambda function.

### Orchestrator Endpoint

The orchestrator exposes a `/process` endpoint that accepts `OrchestratorPayload`:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `customer_id` | string | Yes | Customer account identifier |
| `intent` | string | Yes | Customer's query or request |
| `session_id` | string | No | Session ID for conversation tracking |
| `priority` | string | No | Priority level: `low`, `medium`, `high`, `critical` (default: `medium`) |
| `metadata` | object | No | Additional context (channel, source, etc.) |

### Response Structure

The orchestrator returns `OrchestratorResponse`:

| Field | Type | Description |
|-------|------|-------------|
| `request_id` | string | Unique request identifier |
| `customer_id` | string | Customer account identifier |
| `intent` | string | Original customer intent |
| `execution_plan` | object | Claude-generated execution plan |
| `security_verification` | object | Security agent verification result |
| `agent_responses` | array | Responses from utility agents |
| `final_response` | string | Synthesized customer response |
| `success` | boolean | Whether request was successful |
| `blocked_by_security` | boolean | Whether security agent blocked execution |
| `requires_escalation` | boolean | Whether human escalation is needed |
| `escalation_reason` | string | Reason for escalation if required |

### Sample Lambda Function (Python)

```python
"""Lambda function to invoke Contact Center Orchestrator."""

import json
import logging
import os
from typing import Any

import boto3
import urllib3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Configuration
ORCHESTRATOR_URL = os.environ.get("ORCHESTRATOR_URL", "http://orchestrator:8080")
REQUEST_TIMEOUT = int(os.environ.get("REQUEST_TIMEOUT", "60"))

http = urllib3.PoolManager()


def build_orchestrator_payload(
    customer_id: str,
    intent: str,
    session_id: str | None = None,
    priority: str = "medium",
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the payload for orchestrator invocation.
    
    Args:
        customer_id: Customer account identifier
        intent: Customer's query or request
        session_id: Optional session ID for conversation tracking
        priority: Request priority (low, medium, high, critical)
        metadata: Additional context information
        
    Returns:
        Dictionary payload for orchestrator /process endpoint
    """
    payload = {
        "customer_id": customer_id,
        "intent": intent,
        "priority": priority,
        "metadata": metadata or {},
    }
    
    if session_id:
        payload["session_id"] = session_id
        
    return payload


def invoke_orchestrator(payload: dict[str, Any]) -> dict[str, Any]:
    """Invoke the orchestrator agent.
    
    Args:
        payload: OrchestratorPayload dictionary
        
    Returns:
        OrchestratorResponse dictionary
        
    Raises:
        Exception: If orchestrator invocation fails
    """
    url = f"{ORCHESTRATOR_URL}/process"
    
    logger.info(f"Invoking orchestrator at {url}")
    logger.info(f"Payload: {json.dumps(payload)}")
    
    response = http.request(
        "POST",
        url,
        body=json.dumps(payload),
        headers={"Content-Type": "application/json"},
        timeout=REQUEST_TIMEOUT,
    )
    
    if response.status != 200:
        error_msg = f"Orchestrator returned status {response.status}: {response.data.decode()}"
        logger.error(error_msg)
        raise Exception(error_msg)
    
    result = json.loads(response.data.decode())
    logger.info(f"Orchestrator response: success={result.get('success')}")
    
    return result


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Lambda handler for contact center requests.
    
    Expected event structure:
    {
        "customer_id": "CUST-12345",
        "intent": "What is my current bill?",
        "session_id": "sess-abc123",  # optional
        "priority": "medium",          # optional
        "metadata": {                  # optional
            "channel": "chat",
            "source": "web_portal"
        }
    }
    """
    logger.info(f"Received event: {json.dumps(event)}")
    
    try:
        # Validate required fields
        customer_id = event.get("customer_id")
        intent = event.get("intent")
        
        if not customer_id:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "customer_id is required"})
            }
            
        if not intent:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "intent is required"})
            }
        
        # Build payload
        payload = build_orchestrator_payload(
            customer_id=customer_id,
            intent=intent,
            session_id=event.get("session_id"),
            priority=event.get("priority", "medium"),
            metadata=event.get("metadata", {}),
        )
        
        # Invoke orchestrator
        result = invoke_orchestrator(payload)
        
        # Check for security block
        if result.get("blocked_by_security"):
            logger.warning(f"Request blocked by security: {result.get('escalation_reason')}")
        
        # Check for escalation
        if result.get("requires_escalation"):
            logger.info(f"Request requires escalation: {result.get('escalation_reason')}")
            # TODO: Trigger escalation workflow (e.g., create ticket, notify agent)
        
        return {
            "statusCode": 200,
            "body": json.dumps({
                "request_id": result.get("request_id"),
                "response": result.get("final_response"),
                "success": result.get("success"),
                "requires_escalation": result.get("requires_escalation"),
                "escalation_reason": result.get("escalation_reason"),
            })
        }
        
    except Exception as e:
        logger.error(f"Error processing request: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
```

### Sample Lambda Function (Using Boto3 for AgentCore)

If invoking AgentCore runtime directly via AWS SDK:

```python
"""Lambda function to invoke Contact Center Orchestrator via AgentCore."""

import json
import logging
import os
from typing import Any

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Configuration
ORCHESTRATOR_RUNTIME_ARN = os.environ["ORCHESTRATOR_RUNTIME_ARN"]
AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")

bedrock_agent = boto3.client("bedrock-agent-runtime", region_name=AWS_REGION)


def build_orchestrator_payload(
    customer_id: str,
    intent: str,
    session_id: str | None = None,
    priority: str = "medium",
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the payload for orchestrator invocation."""
    payload = {
        "customer_id": customer_id,
        "intent": intent,
        "priority": priority,
        "metadata": metadata or {},
    }
    if session_id:
        payload["session_id"] = session_id
    return payload


def invoke_orchestrator_agentcore(payload: dict[str, Any]) -> dict[str, Any]:
    """Invoke the orchestrator via AgentCore runtime.
    
    Args:
        payload: OrchestratorPayload dictionary
        
    Returns:
        OrchestratorResponse dictionary
    """
    logger.info(f"Invoking AgentCore runtime: {ORCHESTRATOR_RUNTIME_ARN}")
    
    response = bedrock_agent.invoke_agent(
        agentId=ORCHESTRATOR_RUNTIME_ARN.split("/")[-1],
        agentAliasId="TSTALIASID",  # Use appropriate alias
        sessionId=payload.get("session_id", "default-session"),
        inputText=json.dumps(payload),
    )
    
    # Process streaming response
    result_text = ""
    for event in response.get("completion", []):
        if "chunk" in event:
            result_text += event["chunk"]["bytes"].decode()
    
    return json.loads(result_text)


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Lambda handler for contact center requests."""
    logger.info(f"Received event: {json.dumps(event)}")
    
    try:
        customer_id = event.get("customer_id")
        intent = event.get("intent")
        
        if not customer_id or not intent:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "customer_id and intent are required"})
            }
        
        payload = build_orchestrator_payload(
            customer_id=customer_id,
            intent=intent,
            session_id=event.get("session_id"),
            priority=event.get("priority", "medium"),
            metadata=event.get("metadata", {}),
        )
        
        result = invoke_orchestrator_agentcore(payload)
        
        return {
            "statusCode": 200,
            "body": json.dumps({
                "request_id": result.get("request_id"),
                "response": result.get("final_response"),
                "success": result.get("success"),
                "requires_escalation": result.get("requires_escalation"),
            })
        }
        
    except Exception as e:
        logger.error(f"Error: {e}")
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}
```

### Lambda Environment Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `ORCHESTRATOR_URL` | HTTP endpoint for orchestrator | `http://orchestrator:8080` |
| `ORCHESTRATOR_RUNTIME_ARN` | AgentCore runtime ARN | `arn:aws:bedrock:us-east-1:123456789:agent-runtime/xyz` |
| `REQUEST_TIMEOUT` | Request timeout in seconds | `60` |
| `AWS_REGION` | AWS region | `us-east-1` |

### Lambda IAM Permissions

```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "bedrock:InvokeAgent"
            ],
            "Resource": "arn:aws:bedrock:*:*:agent-runtime/*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "logs:CreateLogGroup",
                "logs:CreateLogStream",
                "logs:PutLogEvents"
            ],
            "Resource": "arn:aws:logs:*:*:*"
        }
    ]
}
```

### Sample Test Events

**Basic Query:**
```json
{
    "customer_id": "CUST-12345",
    "intent": "What is my current account balance?"
}
```

**With Session and Priority:**
```json
{
    "customer_id": "CUST-12345",
    "intent": "I need help with a billing dispute",
    "session_id": "sess-abc123",
    "priority": "high",
    "metadata": {
        "channel": "phone",
        "source": "ivr",
        "callback_number": "+1234567890"
    }
}
```

**Multi-Domain Query:**
```json
{
    "customer_id": "CUST-12345",
    "intent": "What is my bill and are there any service outages in my area?",
    "priority": "medium",
    "metadata": {
        "channel": "chat",
        "location": "Seattle, WA"
    }
}
```

### Error Handling

The Lambda should handle these scenarios:

1. **Security Block**: When `blocked_by_security` is true, the request was denied by the security agent
2. **Escalation Required**: When `requires_escalation` is true, trigger human handoff workflow
3. **Partial Success**: Check individual `agent_responses` for partial failures
4. **Timeout**: Implement appropriate timeout handling for long-running requests

```python
# Example escalation handling
if result.get("requires_escalation"):
    # Create support ticket
    create_escalation_ticket(
        customer_id=customer_id,
        intent=intent,
        reason=result.get("escalation_reason"),
        agent_responses=result.get("agent_responses"),
    )
    
    # Notify human agent
    notify_support_queue(
        priority=payload.get("priority"),
        customer_id=customer_id,
    )
```
