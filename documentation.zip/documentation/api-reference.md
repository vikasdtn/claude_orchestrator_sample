# API Reference

## Orchestrator API

### Base URL
```
http://<orchestrator-host>:8080
```

### Endpoints

#### POST /process

Process a customer intent through the orchestrator.

**Request Body**
```json
{
  "customer_id": "string (required)",
  "intent": "string (required)",
  "session_id": "string (optional)",
  "priority": "low | medium | high | critical (default: medium)",
  "metadata": "object (optional)"
}
```

**Response**
```json
{
  "request_id": "uuid",
  "customer_id": "string",
  "intent": "string",
  "execution_plan": {
    "plan_id": "string",
    "customer_id": "string",
    "intent": "string",
    "steps": [
      {
        "step_number": 1,
        "agent_type": "billing",
        "instruction": "string",
        "depends_on": [],
        "reason": "string"
      }
    ],
    "estimated_complexity": "low | medium | high",
    "requires_human_review": false,
    "human_review_reason": null
  },
  "agent_responses": [
    {
      "request_id": "string",
      "agent_type": "string",
      "success": true,
      "response": "string",
      "tools_used": ["tool1", "tool2"],
      "data": {},
      "confidence": 0.95,
      "requires_escalation": false,
      "escalation_reason": null,
      "timestamp": "2024-01-01T00:00:00Z"
    }
  ],
  "final_response": "string",
  "success": true,
  "requires_escalation": false,
  "escalation_reason": null
}
```

**Example**
```bash
curl -X POST http://localhost:8080/process \
  -H "Content-Type: application/json" \
  -d '{
    "customer_id": "cust-12345",
    "intent": "What is my current account balance?",
    "priority": "medium"
  }'
```

#### GET /health

Health check endpoint.

**Response**
```json
{
  "agent_type": "orchestrator",
  "status": "healthy",
  "model_id": "anthropic.claude-3-sonnet-20240229-v1:0",
  "utility_agents": ["billing", "faq", "..."]
}
```

#### GET /agents

List available utility agents.

**Response**
```json
{
  "agents": {
    "billing": "http://billing:8080",
    "faq": "http://faq:8080",
    "..."
  }
}
```

---

## Utility Agent API

All utility agents share the same API interface.

### Base URL
```
http://<agent-name>:8080
```

### Endpoints

#### POST /process

Process a query through the utility agent.

**Request Body**
```json
{
  "query": "string (required)",
  "customer_id": "string (optional)",
  "priority": "low | medium | high | critical (default: medium)",
  "context": "object (optional)"
}
```

**Response**
```json
{
  "request_id": "uuid",
  "agent_type": "billing",
  "success": true,
  "response": "Your current balance is $150.00",
  "tools_used": ["get_account_balance"],
  "data": {
    "tool_results": [
      {
        "tool_name": "get_account_balance",
        "success": true,
        "result": {"balance": 150.00, "currency": "USD"},
        "execution_time_ms": 234
      }
    ]
  },
  "confidence": 0.95,
  "requires_escalation": false,
  "escalation_reason": null,
  "timestamp": "2024-01-01T00:00:00Z"
}
```

#### GET /health

Health check endpoint.

**Response**
```json
{
  "agent_type": "billing",
  "status": "healthy",
  "model_id": "anthropic.claude-3-sonnet-20240229-v1:0",
  "gateway_url": "http://gateway:8080",
  "available_tools": ["get_account_balance", "get_invoices", "..."]
}
```

---

## Data Models

### OrchestratorPayload
```typescript
{
  customer_id: string;      // Required - Customer account ID
  intent: string;           // Required - Customer query/intent
  session_id?: string;      // Optional - Session tracking ID
  priority?: Priority;      // Optional - Request priority
  metadata?: object;        // Optional - Additional context
}
```

### SecurityVerificationRequest
```typescript
{
  request_id: string;       // Unique request identifier
  customer_id: string;      // Customer account ID
  intent: string;           // Original customer intent
  execution_plan: ExecutionPlan;  // Plan to be verified
  priority: Priority;       // Request priority
  metadata: object;         // Additional context
}
```

### SecurityVerificationResponse
```typescript
{
  request_id: string;       // Original request identifier
  approved: boolean;        // Whether plan is approved
  risk_level: RiskLevel;    // low, medium, high, critical
  denial_reason?: string;   // Reason if denied
  modified_plan?: ExecutionPlan;  // Modified plan if suggested
  restrictions: string[];   // Restrictions on execution
  required_audit: boolean;  // Whether audit logging required
  audit_id?: string;        // Security audit trail ID
}
```

### ExecutionPlan
```typescript
{
  plan_id: string;
  customer_id: string;
  intent: string;
  steps: ExecutionStep[];
  estimated_complexity: "low" | "medium" | "high";
  requires_human_review: boolean;
  human_review_reason?: string;
}
```

### ExecutionStep
```typescript
{
  step_number: number;
  agent_type: AgentType;
  instruction: string;
  depends_on: number[];     // Step numbers this depends on
  reason: string;
}
```

### AgentResponse
```typescript
{
  request_id: string;
  agent_type: string;
  success: boolean;
  response: string;
  tools_used: string[];
  data: object;
  confidence: number;       // 0.0 to 1.0
  requires_escalation: boolean;
  escalation_reason?: string;
  timestamp: string;        // ISO 8601
}
```

### OrchestratorResponse
```typescript
{
  request_id: string;
  customer_id: string;
  intent: string;
  execution_plan: ExecutionPlan;
  security_verification?: SecurityVerificationResponse;  // Security check result
  agent_responses: AgentResponse[];
  final_response: string;
  success: boolean;
  blocked_by_security: boolean;  // True if security denied
  requires_escalation: boolean;
  escalation_reason?: string;
}
```

### ToolResult
```typescript
{
  tool_name: string;
  success: boolean;
  result: object;
  error?: string;
  execution_time_ms: number;
}
```

### Priority Enum
```typescript
"low" | "medium" | "high" | "critical"
```

### RiskLevel Enum
```typescript
"low" | "medium" | "high" | "critical"
```

### AgentType Enum
```typescript
"product_info" | "faq" | "known_outages" | "service_info" |
"ticket_updates" | "billing" | "sales" | "technical_support" | "account_admin"
```

---

## Error Responses

### 400 Bad Request
```json
{
  "detail": "Validation error message"
}
```

### 503 Service Unavailable
```json
{
  "detail": "Agent not initialized"
}
```

### 500 Internal Server Error
```json
{
  "detail": "Internal server error"
}
```

---

## Rate Limits

| Endpoint | Rate Limit |
|----------|------------|
| /process | 100 req/min per customer |
| /health | 1000 req/min |

---

## Authentication

Currently, the API does not implement authentication. In production:
- Use API Gateway with IAM authentication
- Or implement JWT token validation
- Ensure VPC-only access for internal services
