# Architecture Design Document

## Overview

The Multi-Agent Orchestrator Utility Agent System is an AI-powered customer support platform that uses specialized agents to handle different types of customer inquiries. The system is built on AWS Bedrock AgentCore runtime and uses Claude for intelligent query routing and tool selection.

## System Architecture

```
                                    ┌─────────────────────────────────────┐
                                    │         External Channels           │
                                    │   (Voice, Chat, Email, Portal)      │
                                    └─────────────────┬───────────────────┘
                                                      │
                                                      ▼
                                    ┌─────────────────────────────────────┐
                                    │         Amazon Connect /            │
                                    │         API Gateway                 │
                                    └─────────────────┬───────────────────┘
                                                      │
                                                      ▼
                                    ┌─────────────────────────────────────┐
                                    │         Lambda Function             │
                                    │    (Payload: customer_id, intent)   │
                                    └─────────────────┬───────────────────┘
                                                      │
                                                      ▼
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                              Multi-Agent Orchestrator (Orchestrator)                   │
│                              [AWS Bedrock AgentCore Runtime]                            │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐   │
│  │                           Claude Execution Planner                               │   │
│  │  • Analyzes customer intent                                                      │   │
│  │  • Creates execution plan with agent sequence                                    │   │
│  │  • Determines complexity and escalation needs                                    │   │
│  └─────────────────────────────────────────────────────────────────────────────────┘   │
│                                           │                                             │
│                                           ▼                                             │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐   │
│  │                      Security Verification (External)                            │   │
│  │  • Receives execution plan for review                                           │   │
│  │  • Assesses risk level (low/medium/high/critical)                               │   │
│  │  • Approves, denies, or modifies plan                                           │   │
│  │  • Returns restrictions if any                                                   │   │
│  └─────────────────────────────────────────────────────────────────────────────────┘   │
│                                           │                                             │
│                          ┌────────────────┴────────────────┐                           │
│                          │                                 │                           │
│                    [APPROVED]                         [DENIED]                         │
│                          │                                 │                           │
│                          ▼                                 ▼                           │
│  ┌──────────────────────────────────────┐   ┌──────────────────────────────────┐     │
│  │        Execute Plan                   │   │     Return Security Denial       │     │
│  │  ┌────────┐ ┌────────┐ ┌────────┐   │   │  • Customer-friendly message     │     │
│  │  │Agent 1 │ │Agent 2 │ │Agent N │   │   │  • Escalation to human           │     │
│  │  └────────┘ └────────┘ └────────┘   │   │  • Audit trail                   │     │
│  └──────────────────────────────────────┘   └──────────────────────────────────┘     │
│                          │                                                             │
│                          ▼                                                             │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐   │
│  │                         Claude Response Synthesizer                              │   │
│  │                    (Combines agent responses into final)                         │   │
│  └─────────────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────────────┘
                                                      │
                                                      ▼
                              ┌─────────────────────────────────────┐
                              │       AgentCore Gateway             │
                              │  ┌─────────┐ ┌─────────┐ ┌───────┐ │
                              │  │Salesforce│ │Confluence│ │ServiceNow│
                              │  └─────────┘ └─────────┘ └───────┘ │
                              │  ┌─────────┐ ┌─────────┐           │
                              │  │ Billing │ │Diagnostics│          │
                              │  └─────────┘ └─────────┘           │
                              └─────────────────────────────────────┘
```

## Component Design

### 1. Orchestrator Agent

**Purpose**: Central coordinator that receives customer intents and orchestrates utility agents.

**Responsibilities**:
- Receive payload from Lambda (customer_id, intent)
- Use Claude to analyze intent and create execution plan
- Invoke utility agents according to plan
- Synthesize final response from agent outputs
- Handle escalation decisions

**Key Classes**:
```python
class OrchestratorAgent:
    - process_payload(payload: OrchestratorPayload) -> OrchestratorResponse
    - _create_execution_plan(payload, request_id) -> ExecutionPlan
    - _execute_plan(plan, payload) -> list[AgentResponse]
    - _synthesize_response(intent, responses, plan) -> str
```

### 2. Utility Agents

**Purpose**: Specialized agents that handle specific domains.

| Agent | Domain | External Systems |
|-------|--------|------------------|
| Product Info | Product details, specs, pricing | Confluence, Salesforce |
| FAQ | Common questions | Confluence |
| Known Outages | Incidents, maintenance | ServiceNow |
| Service Info | Service availability | Salesforce, Confluence |
| Ticket Updates | Support tickets | ServiceNow |
| Billing | Invoices, payments | Billing System |
| Sales | Promotions, quotes | Salesforce |
| Technical Support | Troubleshooting | Confluence, ServiceNow |
| Account Admin | Account management | Salesforce |

**Base Class Design**:
```python
class BaseUtilityAgent(ABC):
    @property
    @abstractmethod
    def system_prompt(self) -> str
    
    @property
    @abstractmethod
    def available_tools(self) -> list[dict]
    
    @abstractmethod
    def execute_tool(self, tool_name, tool_input) -> ToolResult
    
    async def process_request(self, request) -> AgentResponse
```

### 3. Claude Client

**Purpose**: Interface to AWS Bedrock for Claude model invocations.

**Methods**:
- `invoke()` - Basic text completion
- `invoke_json()` - JSON response parsing
- `invoke_with_tools()` - Tool use with Claude's native tool calling

### 4. AgentCore Gateway Client

**Purpose**: Unified interface to external systems via AgentCore Gateway.

**Supported Systems**:
- Salesforce (CRM, Products, Accounts)
- Confluence (Knowledge Base)
- ServiceNow (Incidents, Tickets)
- Billing System (Invoices, Payments)
- Diagnostic APIs

## Data Flow

### Request Processing Flow

```
1. Lambda receives event with customer_id and intent
2. Lambda invokes Orchestrator AgentCore runtime
3. Orchestrator uses Claude to create ExecutionPlan
4. Orchestrator sends plan to External Security Agent for verification
5. Security Agent assesses risk and returns approval/denial
6. If DENIED:
   a. Return security denial response to customer
   b. Flag for human escalation
   c. Log audit trail
7. If APPROVED:
   a. Use modified plan if security agent provided one
   b. Apply any restrictions from security agent
   c. For each step in plan:
      - Orchestrator invokes utility agent via AgentCore
      - Utility agent uses Claude to select tools
      - Tools execute via AgentCore Gateway
      - Utility agent returns AgentResponse
8. Orchestrator uses Claude to synthesize final response
9. OrchestratorResponse returned to Lambda (includes security verification result)
```

### Security Verification Flow

```
┌─────────────┐     ┌─────────────────┐     ┌─────────────────┐
│ Orchestrator│────▶│ Security Agent  │────▶│   Risk Engine   │
│             │     │   /verify       │     │                 │
└─────────────┘     └─────────────────┘     └─────────────────┘
       │                    │                       │
       │                    │                       │
       │            ┌───────▼───────┐              │
       │            │ Assess Plan:  │              │
       │            │ • Customer ID │              │
       │            │ • Intent      │              │
       │            │ • Agent Steps │              │
       │            │ • Priority    │              │
       │            └───────┬───────┘              │
       │                    │                       │
       │            ┌───────▼───────┐              │
       │            │ Return:       │              │
       │            │ • approved    │              │
       │            │ • risk_level  │              │
       │            │ • denial_reason│             │
       │            │ • modified_plan│             │
       │            │ • restrictions │             │
       │            │ • audit_id    │              │
       │            └───────┬───────┘              │
       │                    │                       │
       ◀────────────────────┘                       │
```

### Security Verification Request/Response

**Request to Security Agent:**
```json
{
  "request_id": "uuid",
  "customer_id": "cust-123",
  "intent": "Transfer $10000 to account XYZ",
  "execution_plan": {
    "plan_id": "plan-uuid",
    "steps": [
      {"step_number": 1, "agent_type": "billing", "instruction": "..."},
      {"step_number": 2, "agent_type": "account_admin", "instruction": "..."}
    ],
    "estimated_complexity": "high"
  },
  "priority": "high",
  "metadata": {}
}
```

**Response from Security Agent:**
```json
{
  "request_id": "uuid",
  "approved": false,
  "risk_level": "critical",
  "denial_reason": "High-value transfer requires additional verification",
  "modified_plan": null,
  "restrictions": [],
  "required_audit": true,
  "audit_id": "audit-12345"
}
```

### Execution Plan Structure

```json
{
  "plan_id": "plan-uuid",
  "customer_id": "cust-123",
  "intent": "What is my bill and are there any outages?",
  "steps": [
    {
      "step_number": 1,
      "agent_type": "billing",
      "instruction": "Get current account balance and recent invoices",
      "depends_on": [],
      "reason": "Customer asking about bill"
    },
    {
      "step_number": 2,
      "agent_type": "known_outages",
      "instruction": "Check for active outages affecting customer",
      "depends_on": [],
      "reason": "Customer asking about outages"
    }
  ],
  "estimated_complexity": "medium",
  "requires_human_review": false
}
```

## Infrastructure Architecture

### AWS Bedrock AgentCore Runtime

```
┌─────────────────────────────────────────────────────────────────┐
│                    AWS Bedrock AgentCore                         │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                  Agent Runtimes                          │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐     │   │
│  │  │ Orchestrator│  │   Billing   │  │    FAQ      │     │   │
│  │  │   Runtime   │  │   Runtime   │  │   Runtime   │     │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘     │   │
│  │                         ...                              │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐     │   │
│  │  │   Sales     │  │  Technical  │  │   Account   │     │   │
│  │  │   Runtime   │  │   Support   │  │    Admin    │     │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘     │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │              AgentCore Gateway                           │   │
│  │         (External System Integration)                    │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │              Built-in Memory Service                     │   │
│  │           (Session & Conversation State)                 │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
│      ECR        │  │  CloudWatch     │  │    Bedrock      │
│  (Container     │  │  (Logs/Metrics) │  │  (Claude Model) │
│   Registry)     │  │                 │  │                 │
└─────────────────┘  └─────────────────┘  └─────────────────┘
```

### AgentCore Benefits

- **Zero Infrastructure Management**: No VPC, subnets, or load balancers to manage
- **Built-in Gateway**: Integrated tool execution and external system connectivity
- **Auto-scaling**: Automatic scaling based on demand
- **Native Bedrock Integration**: Direct access to Claude and other foundation models
- **Memory Service**: Built-in session and conversation state management

### Agent Communication

Agents communicate via AgentCore's native invocation mechanism:
- Orchestrator invokes utility agents using their runtime ARNs
- All inter-agent communication is managed by AgentCore
- No need for service discovery or internal load balancing

## Security Design

### IAM Roles
- AgentCore Runtime Role: Bedrock invoke, ECR pull, CloudWatch logs
- Least-privilege access to required AWS services

### Data Security
- No PII stored in agent memory
- Customer IDs used for lookups only
- All external calls via Gateway (centralized audit)
- AgentCore provides built-in encryption at rest and in transit

## Scalability

### Automatic Scaling
- AgentCore automatically scales agent runtimes based on demand
- No manual capacity planning required
- Each agent scales independently

### Capacity Planning

| Environment | Configuration |
|-------------|---------------|
| Dev | Default AgentCore scaling |
| Staging | Default AgentCore scaling |
| Production | Default AgentCore scaling with monitoring |

## Resilience

### Failure Handling
- AgentCore provides automatic container restart on failure
- Built-in health monitoring
- Fallback execution plan if Claude unavailable
- Escalation to human on repeated failures

### Circuit Breaker Pattern
- Gateway client implements timeouts
- Failed tool calls return error results
- Agents continue with partial information

## Monitoring

### Key Metrics
- Request latency (p50, p95, p99)
- Error rates by agent
- Tool execution times
- Claude token usage
- Escalation rates

### CloudWatch Integration
- All agent logs sent to CloudWatch
- Log group: `/aws/bedrock/agentcore/contact-center-{environment}`
- Metrics available via CloudWatch Metrics

### Alerting
- High error rate (>5%)
- Latency spike (p95 > 10s)
- Agent runtime failures
- Bedrock throttling
