# Operations Guide

## Overview

This guide covers operational procedures for the Multi-Agent Orchestrator Utility Agent System deployed on AWS Bedrock AgentCore runtime.

## System Health Monitoring

### Health Check Endpoints

All agents expose a `/health` endpoint:

```bash
# Health checks are managed by AgentCore runtime
# View agent status via AWS CLI or Console
aws bedrock get-agent-runtime --agent-runtime-id <runtime-id>
```

### CloudWatch Metrics

#### Key Metrics to Monitor

| Metric | Description | Alert Threshold |
|--------|-------------|-----------------|
| `RequestLatency` | End-to-end request time | p95 > 10s |
| `ErrorRate` | Percentage of failed requests | > 5% |
| `ToolExecutionTime` | Gateway tool call duration | p95 > 5s |
| `EscalationRate` | Requests requiring human review | > 20% |
| `BedrockThrottling` | Claude API throttle events | > 0 |

### Log Analysis

#### Log Groups

| Log Group | Contents |
|-----------|----------|
| `/aws/bedrock/agentcore/contact-center-{env}` | All agent runtime logs |

#### Useful Log Queries

**Find errors in last hour**:
```
fields @timestamp, @message
| filter @message like /ERROR/
| sort @timestamp desc
| limit 100
```

**Track request flow**:
```
fields @timestamp, @message
| filter @message like /request_id/
| parse @message "request_id=*" as request_id
| sort @timestamp asc
```

**Tool execution times**:
```
fields @timestamp, @message
| filter @message like /execution_time_ms/
| parse @message "execution_time_ms=*" as exec_time
| stats avg(exec_time), max(exec_time) by bin(5m)
```

## Troubleshooting

### Common Issues

#### 1. Agent Runtime Not Responding

**Symptoms**: Invocation failures, timeouts

**Diagnosis**:
```bash
# Check runtime status
aws bedrock get-agent-runtime --agent-runtime-id <runtime-id>

# View CloudWatch logs
aws logs tail /aws/bedrock/agentcore/contact-center-dev --follow
```

**Resolution**:
- Check container image exists in ECR
- Review CloudWatch logs for startup errors
- Verify environment variables are set correctly
- Check IAM role permissions

#### 2. Claude/Bedrock Errors

**Symptoms**: "Claude invocation failed" in logs

**Diagnosis**:
```bash
# Test Bedrock access
aws bedrock-runtime invoke-model \
  --model-id anthropic.claude-3-sonnet-20240229-v1:0 \
  --body '{"prompt": "test"}' \
  output.json
```

**Resolution**:
- Verify IAM role has `bedrock:InvokeModel` permission
- Check Bedrock model access is enabled in console
- Review quota limits and request increases if needed

#### 3. Gateway Tool Failures

**Symptoms**: Tool execution returns success=false

**Resolution**:
- Verify gateway URL is correct
- Check gateway service is running
- Review gateway logs for backend errors
- Verify credentials for external systems

#### 4. High Latency

**Symptoms**: Requests taking >10 seconds

**Diagnosis**:
```bash
# Check CloudWatch metrics
aws cloudwatch get-metric-statistics \
  --namespace AWS/Bedrock \
  --metric-name Latency \
  --start-time $(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%SZ) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --period 300 \
  --statistics Average
```

**Resolution**:
- Check Bedrock latency (may need different region)
- Review execution plans for unnecessary steps
- Check gateway backend performance

### Debug Mode

Enable debug logging via Terraform:

```hcl
# In agentcore.tf
environment_variables = {
  LOG_LEVEL = "DEBUG"
}
```

## Maintenance Procedures

### Deploying Updates

#### Update Container Image

```bash
# Build and push new image
./scripts/build_and_push.sh

# AgentCore will automatically pick up the new :latest image
# Or force update via Terraform
cd infrastructure
terraform apply -var-file=environments/dev.tfvars
```

#### Rolling Updates

AgentCore manages rolling updates automatically when container images are updated.

### Scaling

AgentCore automatically scales agent runtimes based on demand. No manual scaling configuration is required.

### Backup and Recovery

#### Configuration Backup

```bash
# Export Terraform state
terraform state pull > backup/terraform-state-$(date +%Y%m%d).json

# Export runtime configurations
aws bedrock list-agent-runtimes > backup/runtimes-$(date +%Y%m%d).json
```

#### Disaster Recovery

1. Terraform state stored in S3 with versioning
2. ECR images tagged with version numbers
3. AgentCore provides built-in high availability

## Incident Response

### Severity Levels

| Level | Description | Response Time |
|-------|-------------|---------------|
| P1 | Complete outage | 15 minutes |
| P2 | Major degradation | 1 hour |
| P3 | Minor issues | 4 hours |
| P4 | Low impact | Next business day |

### Incident Playbook

#### P1: Complete Outage

1. **Assess**: Check AgentCore runtime status
2. **Communicate**: Notify stakeholders
3. **Diagnose**: Review CloudWatch logs and metrics
4. **Mitigate**: 
   - Check ECR images are available
   - Verify IAM permissions
   - Rollback if recent deployment
5. **Resolve**: Fix root cause
6. **Post-mortem**: Document and prevent recurrence

#### P2: High Error Rate

1. Check which agent(s) are failing
2. Review error messages in logs
3. Check external dependencies (Gateway, Bedrock)
4. Verify container images are valid

### Rollback Procedure

```bash
# Tag previous working image as latest
aws ecr batch-get-image \
  --repository-name contact-center/orchestrator \
  --image-ids imageTag=v1.0.0 \
  --query 'images[].imageManifest' \
  --output text | \
aws ecr put-image \
  --repository-name contact-center/orchestrator \
  --image-tag latest \
  --image-manifest file:///dev/stdin

# Reapply Terraform to trigger runtime update
terraform apply -var-file=environments/dev.tfvars
```

## Security Operations

### Access Review

Monthly review of:
- IAM role permissions
- ECR repository policies
- CloudWatch log access

### Audit Logging

All API calls logged via CloudTrail:
- Bedrock model invocations
- AgentCore runtime changes
- IAM policy changes

## Capacity Planning

### AgentCore Limits

AgentCore automatically manages capacity. Monitor these metrics:
- Invocation count
- Concurrent executions
- Bedrock token usage

### Scaling Triggers

AgentCore handles scaling automatically based on:
- Request volume
- Latency targets
- Error rates

## Contacts

| Role | Contact |
|------|---------|
| On-call Engineer | [pager] |
| Platform Team | [email] |
| AWS Support | [case portal] |
