# Code Walkthrough

This document explains the application architecture, code structure, and how each file is used during execution.

## High-Level Execution Flow

```
┌─────────────────┐     ┌─────────────────────────────────────────────────────────┐
│  Lambda         │     │                    Orchestrator                          │
│  Function       │────▶│  main.py (FastAPI) ──▶ agent.py (OrchestratorAgent)     │
└─────────────────┘     └───────────────────────────────┬─────────────────────────┘
                                                        │
                        ┌───────────────────────────────┼───────────────────────────┐
                        │                               ▼                           │
                        │  ┌─────────────────────────────────────────────────────┐ │
                        │  │              Security Agent (External)               │ │
                        │  │                    /verify                           │ │
                        │  └─────────────────────────────────────────────────────┘ │
                        │                               │                           │
                        │                    ┌──────────┴──────────┐               │
                        │                    ▼                     ▼               │
                        │              [APPROVED]             [DENIED]             │
                        │                    │                     │               │
                        │                    ▼                     ▼               │
                        │  ┌─────────────────────────┐   ┌─────────────────────┐  │
                        │  │   Execute Utility       │   │  Return Denial      │  │
                        │  │   Agents                │   │  Response           │  │
                        │  └─────────────────────────┘   └─────────────────────┘  │
                        └───────────────────────────────────────────────────────────┘
                                                        │
                        ┌───────────────────────────────┼───────────────────────────┐
                        │                               ▼                           │
                        │  ┌─────────────────────────────────────────────────────┐ │
                        │  │                  Utility Agent                       │ │
                        │  │  main.py (FastAPI) ──▶ agent.py (extends BaseAgent) │ │
                        │  └───────────────────────────────┬─────────────────────┘ │
                        │                                  │                        │
                        │                                  ▼                        │
                        │  ┌─────────────────────────────────────────────────────┐ │
                        │  │              AgentCore Gateway                       │ │
                        │  │  (Salesforce, Confluence, ServiceNow, Billing)      │ │
                        │  └─────────────────────────────────────────────────────┘ │
                        └───────────────────────────────────────────────────────────┘
```

## Directory Structure

```
contact-center-agents/
├── shared/                      # Shared utilities used by all agents
│   ├── __init__.py
│   ├── models.py               # Pydantic data models
│   ├── base_agent.py           # Base class for utility agents
│   ├── claude_client.py        # Bedrock Claude client
│   └── gateway_client.py       # AgentCore Gateway client
├── orchestrator/                # Super Agent (Orchestrator)
│   ├── __init__.py
│   ├── agent.py                # OrchestratorAgent class
│   └── main.py                 # FastAPI server
├── agents/                      # Utility Agents
│   ├── billing/
│   │   ├── __init__.py
│   │   ├── agent.py            # BillingAgent class
│   │   ├── main.py             # FastAPI server
│   │   └── Dockerfile
│   ├── faq/
│   ├── product_info/
│   └── ... (other agents)
└── infrastructure/              # Terraform IaC
```

---

## Shared Components (`shared/`)

### `models.py` - Data Models

Defines all Pydantic models used for inter-agent communication.

**Key Models:**

| Model | Purpose |
|-------|---------|
| `AgentType` | Enum of all utility agent types |
| `Priority` | Request priority levels (low, medium, high, critical) |
| `AgentRequest` | Input to utility agents |
| `AgentResponse` | Output from utility agents |
| `ToolCall` | Request to invoke a gateway tool |
| `ToolResult` | Response from gateway tool execution |
| `OrchestratorPayload` | Input from Lambda to orchestrator |
| `OrchestratorResponse` | Output from orchestrator to Lambda |
| `ExecutionPlan` | Claude-generated plan of agent steps |
| `ExecutionStep` | Single step in execution plan |
| `SecurityVerificationRequest` | Request to security agent |
| `SecurityVerificationResponse` | Response from security agent |

**Execution Flow Usage:**
1. Lambda sends `OrchestratorPayload` to orchestrator
2. Orchestrator creates `ExecutionPlan` with `ExecutionStep` items
3. Orchestrator sends `SecurityVerificationRequest` to security agent
4. Security agent returns `SecurityVerificationResponse`
5. Orchestrator sends `AgentRequest` to each utility agent
6. Utility agents return `AgentResponse`
7. Orchestrator returns `OrchestratorResponse` to Lambda

---

### `claude_client.py` - Claude/Bedrock Client

Provides interface to AWS Bedrock for Claude model invocations.

**Key Methods:**

```python
class ClaudeClient:
    def invoke(prompt, system_prompt, temperature) -> str
        # Basic text completion
        
    def invoke_json(prompt, system_prompt, temperature) -> dict
        # Returns parsed JSON response
        
    def invoke_with_tools(prompt, tools, system_prompt, temperature) -> dict
        # Tool calling with Claude's native tool use
        # Returns: {"text": str, "tool_calls": list, "stop_reason": str}
```

**Execution Flow Usage:**
1. Orchestrator uses `invoke_json()` to create execution plans
2. Orchestrator uses `invoke()` to synthesize final responses
3. Utility agents use `invoke_with_tools()` to select which tools to call
4. Utility agents use `invoke()` to generate final responses after tool execution

---

### `gateway_client.py` - AgentCore Gateway Client

Provides interface to external systems via AgentCore Gateway.

**Key Methods:**

```python
class AgentCoreGatewayClient:
    def invoke_tool(tool_call: ToolCall) -> ToolResult
        # Generic tool invocation via HTTP
        
    # Convenience methods:
    def query_salesforce(query, object_type) -> ToolResult
    def search_confluence(query, space_key) -> ToolResult
    def get_billing_info(account_id) -> ToolResult
    def query_servicenow(table, query, limit) -> ToolResult
    def create_servicenow_ticket(...) -> ToolResult
```

**Execution Flow Usage:**
- Utility agents call gateway methods to interact with external systems
- All external system calls are routed through the gateway for centralized audit and control

---

### `base_agent.py` - Base Utility Agent Class

Abstract base class that all utility agents extend.

**Key Methods:**

```python
class BaseUtilityAgent(ABC):
    @property
    @abstractmethod
    def system_prompt(self) -> str
        # Agent-specific system prompt for Claude
        
    @property
    @abstractmethod
    def available_tools(self) -> list[dict]
        # Tool definitions in Claude format
        
    @abstractmethod
    def execute_tool(tool_name, tool_input) -> ToolResult
        # Execute a specific tool
        
    async def process_request(request: AgentRequest) -> AgentResponse
        # Main entry point - orchestrates Claude + tool execution
        
    def _check_escalation(request, response, tool_results) -> tuple[bool, str]
        # Determine if human escalation is needed
```

**Execution Flow:**

```
process_request()
    │
    ├──▶ _build_prompt()           # Build prompt with customer context
    │
    ├──▶ claude.invoke_with_tools() # Ask Claude which tools to use
    │
    ├──▶ execute_tool()            # Execute each tool Claude requested
    │    (loops for each tool)
    │
    ├──▶ _get_final_response()     # Get Claude's final response with tool results
    │
    ├──▶ _check_escalation()       # Check if human escalation needed
    │
    └──▶ _build_response()         # Build AgentResponse
```

---

## Orchestrator (`orchestrator/`)

### `main.py` - FastAPI Server

Entry point for the orchestrator service.

**Endpoints:**

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/health` | GET | Health check |
| `/process` | POST | Process customer intent |
| `/agents` | GET | List available utility agents |

**Execution Flow:**
1. FastAPI receives POST to `/process` with `OrchestratorPayload`
2. Calls `orchestrator.process_payload(payload)`
3. Returns `OrchestratorResponse`

---

### `agent.py` - OrchestratorAgent Class

Core orchestration logic with security verification.

**Key Methods:**

```python
class OrchestratorAgent:
    async def process_payload(payload: OrchestratorPayload) -> OrchestratorResponse
        # Main entry point
        
    async def _create_execution_plan(payload, request_id) -> ExecutionPlan
        # Use Claude to analyze intent and create plan
        
    async def _verify_with_security_agent(request_id, payload, plan) -> SecurityVerificationResponse
        # Send plan to external security agent
        
    async def _execute_plan(plan, payload, restrictions) -> list[AgentResponse]
        # Execute approved plan by invoking utility agents
        
    async def _invoke_utility_agent(agent_type, instruction, ...) -> AgentResponse
        # HTTP call to a utility agent
        
    async def _synthesize_response(intent, responses, plan) -> str
        # Use Claude to combine agent responses
```

**Execution Flow:**

```
process_payload(payload)
    │
    ├──▶ _create_execution_plan()
    │    │
    │    ├──▶ claude.invoke_json()     # Claude creates plan
    │    │
    │    └──▶ _create_fallback_plan()  # Keyword-based fallback if Claude fails
    │
    ├──▶ _verify_with_security_agent()
    │    │
    │    └──▶ HTTP POST to security_agent/verify
    │
    ├──▶ [If DENIED] Return security denial response
    │
    ├──▶ [If APPROVED] _execute_plan()
    │    │
    │    └──▶ _invoke_utility_agent()  # For each step in plan
    │         │
    │         └──▶ HTTP POST to agent/process
    │
    ├──▶ _synthesize_response()
    │    │
    │    └──▶ claude.invoke()          # Combine responses
    │
    └──▶ Return OrchestratorResponse
```

**Configuration (Environment Variables):**

| Variable | Purpose |
|----------|---------|
| `PRODUCT_INFO_AGENT_URL` | URL for product info agent |
| `FAQ_AGENT_URL` | URL for FAQ agent |
| `BILLING_AGENT_URL` | URL for billing agent |
| ... | (other agent URLs) |
| `SECURITY_AGENT_URL` | External security agent URL |
| `SECURITY_VERIFICATION_TIMEOUT` | Timeout for security verification |
| `SKIP_SECURITY_VERIFICATION` | Bypass security (dev only) |

---

## Utility Agents (`agents/`)

Each utility agent follows the same pattern:

### `agent.py` - Agent Implementation

Extends `BaseUtilityAgent` with domain-specific logic.

**Required Implementations:**

```python
class BillingAgent(BaseUtilityAgent):
    @property
    def system_prompt(self) -> str:
        # Domain-specific instructions for Claude
        
    @property
    def available_tools(self) -> list[dict]:
        # Tool definitions (name, description, input_schema)
        
    def execute_tool(self, tool_name, tool_input) -> ToolResult:
        # Map tool calls to gateway invocations
        
    def _check_escalation(self, request, response, tool_results):
        # Optional: domain-specific escalation logic
```

**Tool Definition Format:**

```python
{
    "name": "get_account_balance",
    "description": "Get the current account balance for a customer",
    "input_schema": {
        "type": "object",
        "properties": {
            "account_id": {
                "type": "string",
                "description": "Customer account ID"
            }
        },
        "required": ["account_id"]
    }
}
```

---

### `main.py` - FastAPI Server

Entry point for the utility agent service.

**Endpoints:**

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/health` | GET | Health check |
| `/process` | POST | Process agent request |

**Request Model:**

```python
class ProcessRequest(BaseModel):
    query: str                    # Customer query/instruction
    customer_id: str | None       # Customer identifier
    priority: str = "medium"      # Request priority
    context: dict = {}            # Additional context from orchestrator
```

---

## Complete Request Lifecycle

### Step 1: Lambda Invokes Orchestrator

```python
# Lambda sends OrchestratorPayload
{
    "customer_id": "CUST-12345",
    "intent": "What is my current bill and are there any outages?",
    "session_id": "sess-abc123",
    "priority": "medium",
    "metadata": {"channel": "chat"}
}
```

### Step 2: Orchestrator Creates Execution Plan

Claude analyzes the intent and returns:

```json
{
    "steps": [
        {
            "step_number": 1,
            "agent_type": "billing",
            "instruction": "Get current account balance and recent invoices",
            "depends_on": [],
            "reason": "Customer asking about bill"
        },
        {
            "step_number": 2,
            "agent_type": "known_outages",
            "instruction": "Check for active outages affecting customer",
            "depends_on": [],
            "reason": "Customer asking about outages"
        }
    ],
    "estimated_complexity": "medium",
    "requires_human_review": false
}
```

### Step 3: Security Verification

Orchestrator sends plan to security agent:

```json
{
    "request_id": "req-uuid",
    "customer_id": "CUST-12345",
    "intent": "What is my current bill...",
    "execution_plan": { ... },
    "priority": "medium"
}
```

Security agent responds:

```json
{
    "request_id": "req-uuid",
    "approved": true,
    "risk_level": "low",
    "audit_id": "audit-12345"
}
```

### Step 4: Execute Utility Agents

For each step, orchestrator calls utility agent:

```python
# POST to billing agent /process
{
    "request_id": "orch-billing-abc123",
    "query": "Get current account balance and recent invoices",
    "customer_id": "CUST-12345",
    "priority": "medium",
    "context": {}
}
```

### Step 5: Utility Agent Processes Request

1. `BillingAgent.process_request()` is called
2. Claude selects tools: `get_account_balance`, `get_invoices`
3. Agent executes tools via gateway
4. Claude generates response with tool results
5. Returns `AgentResponse`

### Step 6: Synthesize Final Response

Orchestrator uses Claude to combine all agent responses into a coherent customer response.

### Step 7: Return to Lambda

```python
# OrchestratorResponse
{
    "request_id": "req-uuid",
    "customer_id": "CUST-12345",
    "intent": "What is my current bill...",
    "execution_plan": { ... },
    "security_verification": { "approved": true, ... },
    "agent_responses": [ ... ],
    "final_response": "Your current balance is $150.00...",
    "success": true,
    "requires_escalation": false
}
```

---

## File Usage Summary

| File | When Used | Purpose |
|------|-----------|---------|
| `shared/models.py` | Every request | Data serialization/validation |
| `shared/claude_client.py` | Planning, tool selection, synthesis | LLM interactions |
| `shared/gateway_client.py` | Tool execution | External system calls |
| `shared/base_agent.py` | Utility agent requests | Common agent logic |
| `orchestrator/main.py` | Request entry | HTTP server |
| `orchestrator/agent.py` | Request processing | Orchestration logic |
| `agents/*/main.py` | Agent invocation | HTTP server |
| `agents/*/agent.py` | Agent processing | Domain-specific logic |
