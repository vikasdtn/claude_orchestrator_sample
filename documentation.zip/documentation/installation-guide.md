# Installation Guide

## Prerequisites

### Required Software
- Python 3.11+
- Docker 24.0+ with buildx support
- Terraform 1.5+
- AWS CLI v2
- Git

### AWS Requirements
- AWS Account with appropriate permissions
- Bedrock model access enabled (Claude 3 Sonnet)
- Bedrock AgentCore access enabled
- ECR repository access

### Required AWS Permissions
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "ecr:*",
        "logs:*",
        "iam:*",
        "bedrock:InvokeModel",
        "bedrock:InvokeModelWithResponseStream",
        "bedrock:InvokeAgent",
        "bedrock:CreateAgentRuntime",
        "bedrock:UpdateAgentRuntime",
        "bedrock:DeleteAgentRuntime",
        "bedrock:GetAgentRuntime",
        "bedrock:ListAgentRuntimes"
      ],
      "Resource": "*"
    }
  ]
}
```

## Quick Start

### 1. Clone and Setup

```bash
git clone <repository-url>
cd contact-center-agents

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -e ".[dev]"
```

### 2. Configure AWS

```bash
# Configure AWS CLI
aws configure

# Verify Bedrock access
aws bedrock list-foundation-models --query "modelSummaries[?contains(modelId, 'claude')]"
```

### 3. Set Environment Variables

```bash
export AWS_REGION=us-east-1
export BEDROCK_MODEL_ID=anthropic.claude-3-sonnet-20240229-v1:0
export AGENTCORE_GATEWAY_URL=<your-gateway-url>
```

## Deployment

### Infrastructure Deployment

```bash
cd infrastructure

# Initialize Terraform
terraform init

# Review the plan
terraform plan -var-file=environments/dev.tfvars

# Apply infrastructure
terraform apply -var-file=environments/dev.tfvars
```

### Build and Push Docker Images

```bash
cd ..
chmod +x scripts/build_and_push.sh
./scripts/build_and_push.sh
```

### Deploy to AgentCore

```bash
DEPLOY=true ENVIRONMENT=dev ./scripts/build_and_push.sh
```

### Verify Deployment

```bash
terraform output orchestrator_runtime_arn
```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `AWS_REGION` | AWS region | `us-east-1` |
| `BEDROCK_MODEL_ID` | Claude model ID | `anthropic.claude-3-sonnet-20240229-v1:0` |
| `AGENTCORE_GATEWAY_URL` | Gateway URL | - |
| `LOG_LEVEL` | Logging level | `INFO` |

## Local Development

### Running Tests

```bash
./scripts/run_tests.sh
pytest tests/test_orchestrator.py -v
pytest --cov=shared --cov=orchestrator --cov=agents
```

### Local Docker Compose

```bash
docker-compose up -d
docker-compose logs -f orchestrator
docker-compose down
```

## Production Deployment

```bash
cd infrastructure
terraform apply -var-file=environments/prod.tfvars
```

## Troubleshooting

**ECR Authentication Failed**
```bash
aws ecr get-login-password --region $AWS_REGION | \
  docker login --username AWS --password-stdin \
  <account-id>.dkr.ecr.$AWS_REGION.amazonaws.com
```

**Bedrock Access Denied**
- Verify model access in AWS Console
- Check IAM role permissions

**AgentCore Runtime Issues**
```bash
aws logs tail /aws/bedrock/agentcore/contact-center-dev --follow
```

## Next Steps

- [Developer Guide](./developer-guide.md)
- [Architecture Design](./architecture-design.md)
- [Operations Guide](./operations-guide.md)
